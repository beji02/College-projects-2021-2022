#include "PetStoreCosUndoGUI.h"

PetStoreCosUndoGUI::PetStoreCosUndoGUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
